using System;
using td12.Models;
using System.Collections.Generic;

namespace td12.Services
{
    //contrat
    public interface ICustomersRepository
    {
        public List<TblCustomer> GetCustomers();
        public bool DeleteCustomers(int id);
        public TblCustomer InsertCustomer(TblCustomer customer);
        public TblCustomer UpdateCustomer(TblCustomer customer);
    }
}